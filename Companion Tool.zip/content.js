console.log("[TripProfile] Content script loaded on:", window.location.hostname);

const STORAGE_KEY = "tripprofile";

function showToast(message) {
  const existing = document.getElementById("tripprofile-toast");
  if (existing) existing.remove();
  const toast = document.createElement("div");
  toast.id = "tripprofile-toast";
  toast.textContent = message;
  Object.assign(toast.style, {
    position: "fixed", bottom: "24px", right: "24px", zIndex: "2147483647",
    background: "#1a56db", color: "#fff", padding: "10px 18px",
    borderRadius: "8px", fontSize: "14px", fontFamily: "system-ui, sans-serif",
    boxShadow: "0 4px 12px rgba(0,0,0,0.25)", transition: "opacity 0.4s", opacity: "1",
  });
  document.body.appendChild(toast);
  setTimeout(() => { toast.style.opacity = "0"; setTimeout(() => toast.remove(), 400); }, 3000);
}

function sleep(ms) { return new Promise((resolve) => setTimeout(resolve, ms)); }

const API_BASE = "https://travelcompaniontool.replit.app/api";

// ─── ROUTER ────────────────────────────────────────────────────────────────
async function universalFill(profile) {
  const { adults, children, childAges } = profile.autoFillPayload;
  const hostname = window.location.hostname;
  if (hostname.includes("booking.com")) {
    // Booking.com renders the occupancy picker in a way content scripts cannot reach.
    // Show the floating reference panel so the user can fill manually.
    console.log("[TripProfile] Booking.com — showing reference panel (auto-fill not supported)");
    injectFloatingPanel(profile);
    showToast("Booking.com auto-fill isn't supported — use the reference panel to fill manually");
    return true;
  }
  if (hostname.includes("tripadvisor.com")) return await tripAdvisorFill(adults, children, childAges);
  if (hostname.includes("expedia.com") || hostname.includes("hotels.com")) return await expediaFill(adults, children, childAges);
  return await universalFallbackFill(adults, children, childAges);
}

// ─── TRIPADVISOR ───────────────────────────────────────────────────────────
async function tripAdvisorFill(adults, children, childAges) {
  console.log("[TripProfile] TripAdvisor path");

  const triggerSelectors = [
    'button[aria-label*="number of rooms" i]',
    'button[aria-label*="number of guests" i]',
    'button[aria-label*="rooms" i][aria-label*="guests" i]',
    'button[aria-label*="travelers" i]',
  ];
  for (const sel of triggerSelectors) {
    const t = document.querySelector(sel);
    if (t) {
      t.click();
      await sleep(800);
      console.log("[TripProfile] TripAdvisor opened picker via:", sel);
      break;
    }
  }

  // Find scoped picker container (case-insensitive aria match)
  const container = await findPickerContainerGeneric();

  function findStepperBtns(scope) {
    const btns = Array.from(scope.querySelectorAll("button[aria-label]"));
    const match = (re) => btns.find((b) => re.test(b.getAttribute("aria-label") || ""));
    return {
      adultDec: match(/adult.*(less|decrease|decrement|minus|-)|decrease.*adult/i),
      adultInc: match(/adult.*(more|increase|increment|plus|\+)|increase.*adult/i),
      childDec: match(/child.*(less|decrease|decrement|minus|-)|decrease.*child/i),
      childInc: match(/child.*(more|increase|increment|plus|\+)|increase.*child/i),
    };
  }

  let steppers = { adultDec: null, adultInc: null, childDec: null, childInc: null };
  for (let attempt = 0; attempt < 10; attempt++) {
    const scope = container || document;
    steppers = findStepperBtns(scope);
    if (steppers.adultDec && steppers.adultInc) break;
    await sleep(400);
    console.log("[TripProfile] TripAdvisor waiting for steppers, attempt:", attempt);
  }

  if (!steppers.adultDec || !steppers.adultInc) {
    showToast("Open the guest picker first, then try again");
    return false;
  }

  console.log("[TripProfile] TripAdvisor steppers found, filling...");

  for (let i = 0; i < 10; i++) { steppers.adultDec.click(); await sleep(80); }
  await sleep(300);
  for (let i = 1; i < adults; i++) { steppers.adultInc.click(); await sleep(200); }
  await sleep(300);

  let childrenFilled = true;
  if (children > 0) {
    if (!steppers.childDec || !steppers.childInc) {
      childrenFilled = false;
      console.log("[TripProfile] TripAdvisor: child stepper pair missing");
    } else {
      for (let i = 0; i < 10; i++) { steppers.childDec.click(); await sleep(80); }
      await sleep(300);
      for (let i = 0; i < children; i++) { steppers.childInc.click(); await sleep(300); }
      await sleep(500);
    }
  }

  let agesFilled = true;
  if (children > 0 && childrenFilled && Array.isArray(childAges) && childAges.length > 0) {
    await sleep(800);
    const ageScope = container || document;
    let ageSelects = [];
    for (let attempt = 0; attempt < 6; attempt++) {
      ageSelects = Array.from(ageScope.querySelectorAll(
        'select[aria-label*="age" i],select[aria-label*="child" i],select[id*="age"],select[name*="age"]'
      ));
      console.log("[TripProfile] TripAdvisor age selects:", ageSelects.length);
      if (ageSelects.length >= children) break;
      await sleep(500);
    }
    if (ageSelects.length < children) agesFilled = false;
    const nativeSetter = Object.getOwnPropertyDescriptor(window.HTMLSelectElement.prototype, "value").set;
    for (let i = 0; i < Math.min(ageSelects.length, childAges.length); i++) {
      if (childAges[i] === undefined) continue;
      nativeSetter?.call(ageSelects[i], String(childAges[i]));
      ageSelects[i].dispatchEvent(new Event("change", { bubbles: true }));
      await sleep(200);
    }
  }

  const fullSuccess = childrenFilled && agesFilled;

  if (fullSuccess) {
    await sleep(300);
    const closeScope = container || document;
    const updateBtn = Array.from(closeScope.querySelectorAll("button")).find((b) =>
      /^update$|^done$|^apply$/i.test(b.textContent.trim())
    );
    if (updateBtn) { updateBtn.click(); console.log("[TripProfile] TripAdvisor clicked Update"); }
  } else {
    console.log("[TripProfile] TripAdvisor: skipping Update click — incomplete fill");
  }

  if (fullSuccess) {
    showToast(`Filled: ${adults} adults, ${children} children` +
      (Array.isArray(childAges) && childAges.length > 0 ? `, ages ${childAges.join(", ")}` : ""));
  } else {
    showToast("Partially filled — finish in the picker manually");
  }
  return fullSuccess;
}

// ─── EXPEDIA + HOTELS.COM ──────────────────────────────────────────────────
async function expediaFill(adults, children, childAges) {
  const trigger =
    document.querySelector('[data-stid="open-room-picker"]') ||
    document.querySelector('[data-stid="open-hotel-guest-picker"]') ||
    document.querySelector('[id*="traveler"]') ||
    document.querySelector('[data-testid="travelers-field"]');
  if (trigger) { trigger.click(); await sleep(900); }

  let container =
    document.querySelector('[data-stid="rooms-traveler-selector-menu-container"]') ||
    document.querySelector('[data-stid="traveler-selector-menu-container"]');
  if (!container) container = await findPickerContainerGeneric();
  if (!container) { showToast("Open the guest picker first, then try again"); return false; }

  console.log("[TripProfile] Expedia/Hotels container:", container.className?.slice(0, 60));

  let allBtns = [];
  for (let attempt = 0; attempt < 6; attempt++) {
    allBtns = Array.from(container.querySelectorAll("button"));
    if (allBtns.length >= 4) break;
    await sleep(400);
  }

  const btns = allBtns.filter((b) => {
    const txt = b.textContent.trim().toLowerCase();
    const aria = (b.getAttribute("aria-label") || "").toLowerCase();
    if (txt === "done" || aria === "done") return false;
    if (txt.includes("add another") || aria.includes("add another")) return false;
    if (txt === "remove room" || aria === "remove room") return false;
    return true;
  });

  console.log("[TripProfile] Expedia/Hotels buttons:", btns.map((b) => b.getAttribute("aria-label") || b.textContent.trim().slice(0, 15)));

  if (btns.length < 4) return await universalFallbackFill(adults, children, childAges);

  // adultDec, adultInc, childDec, childInc
  for (let i = 0; i < 10; i++) { btns[0].click(); await sleep(80); }
  await sleep(400);
  for (let i = 1; i < adults; i++) { btns[1].click(); await sleep(400); }
  await sleep(300);
  for (let i = 0; i < 10; i++) { btns[2].click(); await sleep(80); }
  await sleep(400);
  for (let i = 0; i < children; i++) { btns[3].click(); await sleep(500); }

  // Wait for age dropdowns — Hotels.com renders these more slowly than Expedia.
  await sleep(2000);

  let ageSelects = [];
  for (let attempt = 0; attempt < 8; attempt++) {
    const all = Array.from(document.querySelectorAll("select"));
    ageSelects = all.filter((s) => {
      const label = (s.getAttribute("aria-label") || s.getAttribute("name") || s.id || "").toLowerCase();
      const surrounding = s.closest("[class]")?.textContent?.toLowerCase() || "";
      return label.includes("age") || (surrounding.includes("child") && surrounding.includes("age"));
    });
    if (ageSelects.length === 0) {
      ageSelects = Array.from(document.querySelectorAll(
        '[class*="child-age"] select,[data-stid*="age"] select,select[id*="age"],select[name*="age"],[class*="ChildAge"] select,[data-testid*="child-age"] select'
      ));
    }
    console.log("[TripProfile] Age selects attempt", attempt, ":", ageSelects.length, ageSelects.map((s) => s.id || s.getAttribute("aria-label") || s.name));
    if (ageSelects.length >= children) break;
    await sleep(700);
  }

  const nativeSetter = Object.getOwnPropertyDescriptor(window.HTMLSelectElement.prototype, "value").set;
  for (let i = 0; i < ageSelects.length; i++) {
    if (childAges?.[i] === undefined) continue;
    const select = ageSelects[i];
    const age = String(childAges[i]);
    nativeSetter?.call(select, age);
    select.dispatchEvent(new Event("change", { bubbles: true }));
    await sleep(300);
    console.log("[TripProfile] Age", i, "set to:", age, "actual:", select.value);
  }

  const doneBtn = Array.from(container.querySelectorAll("button")).find((b) => /^done$/i.test(b.textContent.trim()));
  if (doneBtn) { await sleep(300); doneBtn.click(); }

  showToast(`Filled: ${adults} adults, ${children} children` + (childAges?.length > 0 ? `, ages ${childAges.join(", ")}` : ""));
  return true;
}

// Booking.com auto-fill removed — the router shows the floating reference panel
// instead because the occupancy picker is unreachable from content scripts.

// ─── UNIVERSAL FALLBACK ────────────────────────────────────────────────────
async function universalFallbackFill(adults, children, childAges) {
  const triggerSelectors = [
    '[data-stid="open-room-picker"]','[data-testid="occupancy-config"]','[data-testid="travelers-field"]',
    'button[aria-label*="traveler" i]','button[aria-label*="guest" i]','button[aria-label*="passenger" i]',
    'button[aria-label*="occupancy" i]','[class*="traveler-selector"]','[class*="guest-picker"]',
    '[class*="occupancy"]','[class*="pax-selector"]','[id*="traveler"]','[id*="guest"]',
  ];
  for (const sel of triggerSelectors) {
    const el = document.querySelector(sel);
    if (el && !el.getAttribute("aria-expanded")) { el.click(); await sleep(800); console.log("[TripProfile] Opened picker with:", sel); break; }
  }

  const container = await findPickerContainerGeneric();
  if (!container) { showToast("Open the guest picker first, then try again"); return false; }

  function findStepperNearLabel(root, labelPattern) {
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, null);
    let node;
    while ((node = walker.nextNode())) {
      const text = node.textContent.trim();
      if (!labelPattern.test(text) || text.length > 20) continue;
      let el = node.parentElement;
      for (let i = 0; i < 4; i++) {
        if (!el || el === root) break;
        const btns = Array.from(el.querySelectorAll("button")).filter((b) => {
          const txt = b.textContent.trim().toLowerCase();
          if (["done","close","apply","search","cancel","ok","add another room","add another","save","update"].includes(txt)) return false;
          if (txt.length >= 20 || txt === "remove room") return false;
          const aria = b.getAttribute("aria-label") || "";
          const cls = typeof b.className === "string" ? b.className : "";
          return /increase|decrease|add|remove|plus|minus/i.test(aria) || /^[+\-−]$/.test(b.textContent.trim()) || /increment|decrement|stepper|increase|decrease|step-input/i.test(cls) || cls.includes("uitk-step");
        });
        if (btns.length >= 2) return { decrease: btns[0], increase: btns[btns.length - 1], label: text };
        el = el.parentElement;
      }
    }
    return null;
  }

  const adultStepper = findStepperNearLabel(container, /^adults?$/i);
  const childStepper = findStepperNearLabel(container, /^children$|^child$/i);

  async function fillStepper(stepper, targetCount, minimum = 0) {
    if (!stepper) return false;
    for (let i = 0; i < 10; i++) { stepper.decrease.click(); await sleep(50); }
    await sleep(300);
    for (let i = 0; i < Math.max(0, targetCount - minimum); i++) { stepper.increase.click(); await sleep(100); }
    await sleep(300);
    return true;
  }

  const adultFilled = await fillStepper(adultStepper, adults, 1);
  const childFilled = await fillStepper(childStepper, children, 0);

  if (children > 0 && Array.isArray(childAges) && childAges.length > 0) {
    await sleep(1500);
    const allSelects = Array.from(document.querySelectorAll("select"));
    let ageSelects = allSelects.filter((s) => {
      const label = (s.getAttribute("aria-label") || s.getAttribute("name") || s.id || "").toLowerCase();
      const surrounding = s.closest("[class]")?.textContent?.toLowerCase() || "";
      return label.includes("age") || (surrounding.includes("child") && surrounding.includes("age"));
    });
    if (ageSelects.length === 0) {
      ageSelects = Array.from(document.querySelectorAll('[class*="child-age"] select,[data-stid*="age"] select,select[id*="age"],select[name*="age"]'));
    }
    const nativeSetter = Object.getOwnPropertyDescriptor(window.HTMLSelectElement.prototype, "value").set;
    for (let i = 0; i < ageSelects.length; i++) {
      if (childAges[i] === undefined) continue;
      const select = ageSelects[i]; const age = String(childAges[i]);
      select.value = age; select.dispatchEvent(new Event("change", { bubbles: true })); await sleep(100);
      if (select.value !== age && nativeSetter) { nativeSetter.call(select, age); select.dispatchEvent(new Event("change", { bubbles: true })); }
      await sleep(150);
    }
  }

  await sleep(400);
  const closeButton = Array.from(container.querySelectorAll("button")).find((b) => /^done$|^apply$|^search$|^close$/i.test(b.textContent.trim()));
  if (closeButton) closeButton.click();

  const success = adultFilled || childFilled;
  showToast(success
    ? `Filled: ${adults} adults, ${children} children` + (Array.isArray(childAges) && childAges.length > 0 ? `, ages ${childAges.join(", ")}` : "")
    : "Could not auto-fill — use the profile card to fill manually"
  );
  return success;
}

async function findPickerContainerGeneric() {
  for (let attempt = 0; attempt < 4; attempt++) {
    const allEls = Array.from(document.querySelectorAll('div,section,form,[role="dialog"],[role="listbox"]'));
    for (const el of allEls) {
      const text = el.innerText || "";
      if (/adults?/i.test(text) && /children|child/i.test(text)) {
        const bc = el.querySelectorAll("button").length;
        if (bc >= 2 && bc < 30) return el;
      }
    }
    await sleep(500);
  }
  return null;
}

async function attemptAutoFill({ manual = false } = {}) {
  console.log("[TripProfile] attemptAutoFill called, hostname:", window.location.hostname, "manual:", manual);
  const result = await chrome.storage.local.get(STORAGE_KEY);
  const profile = result[STORAGE_KEY];
  if (!profile) { if (manual) showToast("No profile yet — open the extension and re-sync."); return false; }
  return universalFill(profile);
}

async function run() {
  await attemptAutoFill({ manual: false });
  const result = await chrome.storage.local.get(STORAGE_KEY);
  const profile = result[STORAGE_KEY];
  if (profile) await scoreAndBadgeReviews(profile);
}

// ─── Floating panel ────────────────────────────────────────────────────────
const PANEL_ID = "tripprofile-floating-panel";

function buildPanelLines(profile) {
  if (!profile) return null;
  const af = profile.autoFillPayload || {};
  const adults = af.adults ?? 0; const children = af.children ?? 0;
  const childAges = Array.isArray(af.childAges) ? af.childAges : [];
  const loyalty = Array.isArray(profile.loyaltyPrograms) ? profile.loyaltyPrograms : [];
  const partyLine = `${adults} adult${adults !== 1 ? "s" : ""}` + (children > 0 ? ` · ${children} child${children !== 1 ? "ren" : ""}` : "");
  const ageLine = childAges.length > 0 ? `Ages: ${childAges.join(", ")}` : null;
  return { partyLine, ageLine, loyalty };
}

function injectFloatingPanel(profile) {
  const existing = document.getElementById(PANEL_ID);
  if (existing) existing.remove();
  const data = buildPanelLines(profile);
  if (!data) return false;

  const panel = document.createElement("div");
  panel.id = PANEL_ID;
  Object.assign(panel.style, { position:"fixed",top:"16px",right:"16px",zIndex:"2147483647",width:"280px",background:"#FAFAF8",border:"1px solid #E5E0D8",borderRadius:"6px",boxShadow:"0 8px 24px rgba(0,0,0,0.18)",fontFamily:"system-ui, -apple-system, sans-serif",color:"#1C1C1C",overflow:"hidden" });

  const header = document.createElement("div");
  Object.assign(header.style, { background:"#6B2737",color:"#fff",padding:"10px 14px",display:"flex",alignItems:"center",justifyContent:"space-between" });
  const title = document.createElement("div");
  title.textContent = "Companion";
  Object.assign(title.style, { fontFamily:"'Playfair Display', Georgia, serif",fontStyle:"italic",fontSize:"16px",fontWeight:"400" });
  const closeBtn = document.createElement("button");
  closeBtn.setAttribute("aria-label","Close"); closeBtn.textContent = "×";
  Object.assign(closeBtn.style, { background:"transparent",border:"none",color:"#fff",fontSize:"20px",lineHeight:"1",cursor:"pointer",padding:"0 4px" });
  closeBtn.addEventListener("click", () => panel.remove());
  header.appendChild(title); header.appendChild(closeBtn); panel.appendChild(header);

  const body = document.createElement("div");
  Object.assign(body.style, { padding:"12px 14px 14px" });

  const partyEl = document.createElement("div");
  partyEl.textContent = data.partyLine;
  Object.assign(partyEl.style, { fontSize:"14px",fontWeight:"600",color:"#1C1C1C",marginBottom:data.ageLine?"2px":"10px" });
  body.appendChild(partyEl);

  if (data.ageLine) {
    const ageEl = document.createElement("div");
    ageEl.textContent = data.ageLine;
    Object.assign(ageEl.style, { fontSize:"12.5px",color:"#5C5248",marginBottom:"10px" });
    body.appendChild(ageEl);
  }

  if (data.loyalty.length > 0) {
    const loyaltyTitle = document.createElement("div");
    loyaltyTitle.textContent = "Loyalty";
    Object.assign(loyaltyTitle.style, { fontSize:"9.5px",fontWeight:"600",letterSpacing:"0.16em",textTransform:"uppercase",color:"#A07840",marginTop:"6px",marginBottom:"5px",paddingTop:"8px",borderTop:"1px solid #E5E0D8" });
    body.appendChild(loyaltyTitle);
    data.loyalty.slice(0, 6).forEach((p) => {
      const row = document.createElement("div");
      Object.assign(row.style, { display:"flex",justifyContent:"space-between",gap:"8px",fontSize:"12px",color:"#1C1C1C",padding:"3px 0" });
      const lbl = document.createElement("span"); lbl.textContent = p.programName || p.brand || "Program"; lbl.style.fontWeight = "500";
      const num = document.createElement("span"); num.textContent = p.membershipNumber || "—";
      Object.assign(num.style, { fontFamily:"ui-monospace,'SF Mono',Menlo,monospace",fontSize:"11px",color:"#5C5248",userSelect:"all" });
      row.appendChild(lbl); row.appendChild(num); body.appendChild(row);
    });
  }

  const footer = document.createElement("div");
  footer.textContent = "Reference while you fill the form";
  Object.assign(footer.style, { marginTop:"10px",paddingTop:"8px",borderTop:"1px solid #E5E0D8",fontFamily:"'Playfair Display', Georgia, serif",fontStyle:"italic",fontSize:"11.5px",color:"#94A39B",textAlign:"center" });
  body.appendChild(footer);
  panel.appendChild(body);
  document.body.appendChild(panel);
  return true;
}

async function showFloatingPanel() {
  const result = await chrome.storage.local.get(STORAGE_KEY);
  const profile = result[STORAGE_KEY];
  if (!profile) { showToast("Sync your Companion profile first."); return false; }
  return injectFloatingPanel(profile);
}

// ─── Review badging ────────────────────────────────────────────────────────
function detectSource(hostname) {
  if (hostname.includes("google.com")) return "google";
  return "google";
}

async function scoreAndBadgeReviews(profile) {
  const reviewEls = document.querySelectorAll("[data-review-text],.review-text,.reviewText,.bui-review-badge__description,.reviews-text");
  if (!reviewEls.length) return;
  const reviews = Array.from(reviewEls).map((el) => el.textContent.trim());
  const propertyId = encodeURIComponent(window.location.pathname + window.location.search);
  const source = detectSource(window.location.hostname);
  let scored;
  try {
    const resp = await fetch(`${API_BASE}/reviews/score`, { method:"POST",credentials:"include",headers:{"Content-Type":"application/json"},body:JSON.stringify({propertyId,source,reviews}) });
    if (!resp.ok) return;
    scored = await resp.json();
  } catch { return; }
  reviewEls.forEach((el, i) => {
    const score = scored[i]; if (!score) return;
    const topTags = (score.tags || []).slice(0, 2);
    const badge = document.createElement("span");
    badge.textContent = `★ ${score.luxuryValueScore}/10${topTags.length ? " · " + topTags.join(", ") : ""}`;
    Object.assign(badge.style, { display:"inline-block",marginLeft:"8px",background:"#eff6ff",border:"1px solid #93c5fd",color:"#1d4ed8",borderRadius:"4px",padding:"2px 7px",fontSize:"12px",fontFamily:"system-ui, sans-serif",verticalAlign:"middle" });
    el.insertAdjacentElement("afterend", badge);
  });
}

// ─── Message listener ──────────────────────────────────────────────────────
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  console.log("[TripProfile] Message received:", msg && msg.type);
  try {
    if (msg?.type === "MANUAL_FILL") {
      attemptAutoFill({ manual: true }).then((ok) => { try { sendResponse({ ok }); } catch (e) {} });
      return true;
    }
    if (msg?.type === "SHOW_PANEL") {
      showFloatingPanel().then((shown) => {
        attemptAutoFill({ manual: false }).catch(() => {});
        try { sendResponse({ ok: shown }); } catch (e) {}
      });
      return true;
    }
  } catch (err) { try { sendResponse({ ok: false, error: String(err) }); } catch (e) {} }
});
